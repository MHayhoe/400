# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 00:13 2018

@author: Hadi
"""
import random

def randomAI(state,actions):
    return random.randint(0,len(actions)-1);
